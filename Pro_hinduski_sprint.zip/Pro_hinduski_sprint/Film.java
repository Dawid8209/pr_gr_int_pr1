import javax.imageio.ImageIO;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.text.DefaultStyledDocument;
import javax.swing.text.DocumentFilter;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Film extends JFrame {

    BufferedImage diuna2 = ImageIO.read(new File("./Obrazki/Diuna2.jpg"));

    public Film() throws IOException {
        JPanel panel = new JPanel();

        JTextArea komentarz = new JTextArea();
        komentarz.setLineWrap(true);
        komentarz.setWrapStyleWord(true);

        // Dodaję ikonę dla przyckisku BACK
        ImageIcon left_arrow = new ImageIcon("./Obrazki/red_arrow.png");
        // Dodanie przycisku BACK
        JButton przyciskBack = new JButton(left_arrow);
        // Zmieniam kolor przycisku na czerwony
        przyciskBack.setBackground(Color.red);
        // Ustawiam kolor borderu przycisku
        przyciskBack.setBorder(new LineBorder(Color.black, 2));

        // Dodaje ikone dla przycisku
        ImageIcon right_arrow = new ImageIcon("./Obrazki/right_arrow.png");

        // Dodanie przycisku next
        JButton przyciskNext = new JButton(right_arrow);
        // Ustawiam kolor przycisku na zielen
        przyciskNext.setBackground(Color.GREEN);
        // Dodaje border
        przyciskNext.setBorder(new LineBorder(Color.BLACK, 4));

        // Dodaje tytul filmu
        JLabel tytul = new JLabel("Przykladowy tytul");
        
        // Dodaje napis Ocena filmu pod obrazek
        JLabel ocena = new JLabel("Ocena filmu");

        // Pole tekstowe do oceny w zależności od ilości gwiazdek
        JLabel poleTekstoweDoOceny = new JLabel("0");
       
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        ImageIcon diun2 = new ImageIcon(diuna2);
        JLabel pickDiuna2 = new JLabel(diun2);
        setTitle("Filmy");

        // Zablokowanie mozliwosci powiekszania ekranu
        setResizable(false);

        // Ustawienie koloru tła
        getContentPane().setBackground(Color.PINK);

        // Ustawienie font size oraz kolor czcionki Tytułu
        tytul.setFont(new Font("Serif", Font.PLAIN, 30));
        tytul.setForeground(Color.GRAY);

        // Ustawiam font size oraz kolor czcionki oceny filmu
        ocena.setFont(new Font("Serif", Font.PLAIN, 30));
        ocena.setForeground(Color.GRAY);

        // Ustawienie wielkości i koloru dla pola tekstowego w zależności od gwiazdek
        poleTekstoweDoOceny.setFont(new Font("Serif", Font.PLAIN, 20));
        poleTekstoweDoOceny.setForeground(Color.black);

        setSize(800, 600);
        setLayout(null);
        pickDiuna2.setBounds((this.getWidth() - diun2.getIconWidth()) / 2,

        (this.getHeight() - diun2.getIconHeight()) / 3, diun2.getIconWidth(), diun2.getIconHeight());
                               
        // Ustawianie pozycji tytułu filmu
        tytul.setBounds(pickDiuna2.getWidth() + 100, pickDiuna2.getHeight() - 270, 300, 100);

        // Ustawianie pozycji oceny filmu
        ocena.setBounds(pickDiuna2.getWidth() + 125, pickDiuna2.getHeight() + 70, 300, 100);

        // Ustawienie pozycji do oceny filmy w zależności od gwiazdek
        poleTekstoweDoOceny.setBounds(pickDiuna2.getWidth() + 200, pickDiuna2.getHeight() + 130, 300, 100);

        // Ustawiam pozycje przycisku BACK
        przyciskBack.setBounds(pickDiuna2.getWidth() - 30, pickDiuna2.getHeight() - 100, 70, 70);

        // Pozycjonuje przycisk
        przyciskNext.setBounds(pickDiuna2.getWidth() + 350, pickDiuna2.getHeight() - 100, 100, 100);

        komentarz.setBounds(pickDiuna2.getWidth() + 45, pickDiuna2.getHeight() + 200, pickDiuna2.getWidth() + 100, 70);

        add(komentarz);
        // Dodaje tytul do panelu
        add(tytul);
        add(pickDiuna2);
        // Dodaje ocene do panelu
        add(ocena);
        // Dodawanie oceny w zależności od gwiazdek
        add(poleTekstoweDoOceny);
        // Dodaje przycisk do panelu
        add(przyciskNext);
        // Dodanie przycisku BACK
        add(przyciskBack);
        add(panel);

        setVisible(true);
    }
}
